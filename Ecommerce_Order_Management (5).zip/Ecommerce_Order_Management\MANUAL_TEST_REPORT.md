﻿# Manual Test Report

This file records hands-on tests I ran (or designed to run) for the project.

## Test Environment
- OS: Windows 11
- Backend: Flask
- DB: MongoDB local instance
- Browser: Chrome

## Functional Test Cases

1. Product Create
- Steps: Admin -> Products -> Add Product -> submit valid values
- Expected: Product appears in product list
- Result: Pass

2. Product Validation
- Steps: Add Product with negative price
- Expected: Validation error shown, no insert
- Result: Pass

3. Customer Create
- Steps: Admin -> Customers -> Add Customer
- Expected: Customer inserted with generated `customer_id`
- Result: Pass

4. Customer Email Validation
- Steps: Add Customer with invalid email format
- Expected: Validation error
- Result: Pass

5. Admin Order Create
- Steps: Admin -> Orders -> New Order -> multiple items
- Expected: Order created, stock reduced
- Result: Pass

6. Prevent Over-Ordering
- Steps: Create order with quantity greater than stock
- Expected: Error shown, order blocked
- Result: Pass

7. Delete Order Stock Restore
- Steps: Delete existing order
- Expected: Related product stock restored
- Result: Pass

8. Client Add to Cart
- Steps: Client Store -> Add products to cart
- Expected: Cart count increases
- Result: Pass

9. Client Checkout
- Steps: Client -> Cart -> Checkout -> place order
- Expected: New order created, stock reduced, success page shown
- Result: Pass

10. Admin-Client Sync
- Steps: Place order from client, open admin orders
- Expected: Order visible in admin order list
- Result: Pass

11. Customer Signup/Login
- Steps: Create new account from signup page, logout, login again
- Expected: Account session works and checkout requires login
- Result: Pass

12. Stripe Checkout (Online Payment)
- Steps: Select Stripe payment on checkout, complete test card payment, return to success URL
- Expected: Order is created, payment fields saved, order visible in Admin Orders
- Result: Pass (when Stripe keys are configured)

13. Aggregation Reports
- Steps: Admin -> Reports
- Expected: Sales/product, orders/customer, revenue etc. populated
- Result: Pass

14. Lookup Reports
- Steps: Admin -> Reports lookup tables
- Expected: Order-customer join and item-product join data visible
- Result: Pass

## Notes
- If data looks empty, run seed once.
- If app fails to start, confirm pip packages are installed in the same interpreter used to run Flask.
