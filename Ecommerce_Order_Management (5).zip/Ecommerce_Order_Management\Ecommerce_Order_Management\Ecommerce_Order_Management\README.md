﻿# E-Commerce Product & Order Management System

This is my full-stack DBMS/MongoDB mini-project built with Flask and MongoDB.

I made it as a practical admin + customer flow app, not just static CRUD pages. The same database is shared between both sides, so whenever a customer places an order, the admin panel reflects it immediately.

## What I Built

### Admin Side
- Product management: add, edit, delete, search, filter
- Customer management: add, edit, delete, search
- Order management: create order, update status, view details, delete with stock restore
- Dashboard cards and charts
- Reports page with aggregation pipelines and lookup outputs

### Client Side
- Product browsing and search
- Cart (add/update/remove/clear)
- Checkout form
- Order placement
- Order tracking by email

## Tech Stack
- Python Flask
- MongoDB + PyMongo
- Jinja2 templates
- HTML, CSS, JS
- Bootstrap 5
- Chart.js
- python-dotenv

## MongoDB Collections
- `products`
- `customers`
- `orders`

### Data Model Choice (quick reasoning)
- `products` and `customers` are master data collections.
- `orders` is transactional data.
- `items` are embedded inside order documents so each order is self-contained.
- I still store `product_id` and `customer_id` to support lookups across collections.

## Indexes Created Automatically
On app startup:
- unique: `products.product_id`
- unique: `customers.customer_id`
- unique: `orders.order_id`
- index: `orders.customer_id`
- index: `orders.items.product_id`

## Aggregation Used in This Project
Implemented reports include:
- total sales per product
- most purchased product
- total revenue
- orders per customer
- top customer by spending
- low stock products
- sales by category

Pipelines use operators like:
- `$match`
- `$unwind`
- `$group`
- `$sum`
- `$project`
- `$sort`
- `$limit`

## Lookup Used in This Project
- Orders joined with customers (order summary)
- Order items joined with products (item-level product details)
- Customer profile joined with orders (order history)

## Project Routes (Important)
- Portal: `http://127.0.0.1:5000/`
- Admin: `http://127.0.0.1:5000/admin`
- Client Store: `http://127.0.0.1:5000/client/products`

## Setup (Windows PowerShell)

```powershell
cd "C:\Users\DEBOJYOTI\Downloads\UPSC GS 1\Ecommerce_Order_Management"
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

If `python` points to another interpreter, use full path:

```powershell
& "C:\Users\DEBOJYOTI\AppData\Local\Programs\Python\Python313\python.exe" app.py
```

## Environment Variables

`.env` example:

```env
SECRET_KEY=change-me-in-production
MONGO_URI=mongodb://127.0.0.1:27017/
DB_NAME=ecommerce_order_management
LOW_STOCK_THRESHOLD=5
FLASK_DEBUG=1
FLASK_HOST=127.0.0.1
FLASK_PORT=5000
```

## Seed Data
Use sidebar buttons in admin:
- `Seed Sample Data`
- `Reset & Seed`

Seed inserts realistic sample products/customers/orders so analytics charts are meaningful.

## Validation Rules Implemented
- no duplicate IDs (`product_id`, `customer_id`, `order_id`)
- positive product price
- non-negative stock
- valid email format
- positive order quantity
- block checkout if stock is insufficient
- required fields on forms

## Submission Screenshots to Add
- Portal page
- Admin dashboard
- Products CRUD
- Customers CRUD
- Orders module
- Client store
- Cart + checkout
- Reports (aggregation + lookup tables)

## What I Tested
I added a separate manual testing file:
- [MANUAL_TEST_REPORT.md](./MANUAL_TEST_REPORT.md)

## Common Issues + Quick Fix
1. `ModuleNotFoundError: pymongo`
- install requirements in the same Python interpreter used to run `app.py`

2. `WinError 10038` while running Flask on Windows
- reloader disabled in app run config

3. Data not visible
- confirm MongoDB service is running
- verify `.env` has correct `MONGO_URI` and `DB_NAME`

## Future Improvements
- authentication for admin/client
- product image upload (file-based)
- pagination + better filtering
- PDF invoice generation
- unit/integration tests

## Viva Quick Answers
1. Why 3 collections?
- Cleaner separation of entities and easier maintenance.

2. Why embed `items` in orders?
- Orders are read along with items most of the time, so embedding is practical.

3. Why keep IDs in orders if items are embedded?
- Needed for joins and reporting with `$lookup`.

4. How is stock handled?
- Reduced at order placement, restored on order deletion/cancel workflows.

5. Where are aggregation and lookup shown?
- Reports page and order/customer detail flows.
