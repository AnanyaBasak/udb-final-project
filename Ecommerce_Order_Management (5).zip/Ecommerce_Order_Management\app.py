import csv
import io
from datetime import datetime, timedelta

import stripe
from flask import Flask, flash, make_response, redirect, render_template, request, session, url_for
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import DuplicateKeyError
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config
from utils import (
    ORDER_STATUSES,
    build_status_badge,
    generate_next_id,
    normalize_phone,
    parse_non_negative_int,
    parse_positive_float,
    parse_positive_int,
    validate_email,
)

app = Flask(__name__)
app.config.from_object(Config)
stripe.api_key = Config.STRIPE_SECRET_KEY or None

mongo_client = MongoClient(Config.MONGO_URI)
db = mongo_client[Config.DB_NAME]


def create_indexes():
    db.products.create_index([("product_id", ASCENDING)], unique=True)
    db.customers.create_index([("customer_id", ASCENDING)], unique=True)
    db.orders.create_index([("order_id", ASCENDING)], unique=True)
    db.orders.create_index([("customer_id", ASCENDING)])
    db.orders.create_index([("items.product_id", ASCENDING)])
    db.users.create_index([("email", ASCENDING)], unique=True)
    db.checkout_sessions.create_index([("session_id", ASCENDING)], unique=True)


create_indexes()


def get_session_cart():
    """
    Session cart format:
    {
        "P101": 2,
        "P104": 1
    }
    """
    raw_cart = session.get("cart", {})
    clean_cart = {}
    if isinstance(raw_cart, dict):
        for product_id, qty in raw_cart.items():
            try:
                parsed_qty = int(qty)
            except (TypeError, ValueError):
                continue
            if parsed_qty > 0:
                clean_cart[str(product_id)] = parsed_qty

    session["cart"] = clean_cart
    return clean_cart


def get_cart_count():
    return sum(get_session_cart().values())


def build_items_from_quantity_map(qty_by_product):
    products = list(db.products.find({"product_id": {"$in": list(qty_by_product.keys())}}))
    product_map = {p["product_id"]: p for p in products}
    errors = []
    items = []

    for pid, qty in qty_by_product.items():
        product = product_map.get(pid)
        if not product:
            errors.append(f"Product {pid} does not exist.")
            continue

        stock = int(product.get("stock", 0))
        if stock < qty:
            errors.append(
                f"Insufficient stock for {product.get('name', pid)}. Available: {stock}, Requested: {qty}."
            )
            continue

        price = float(product.get("price", 0))
        items.append(
            {
                "product_id": pid,
                "product_name": product.get("name", "Unknown Product"),
                "quantity": qty,
                "price": price,
                "subtotal": round(price * qty, 2),
            }
        )

    return items, errors


def reserve_stock(items):
    reserved = []
    for line in items:
        result = db.products.update_one(
            {"product_id": line["product_id"], "stock": {"$gte": line["quantity"]}},
            {"$inc": {"stock": -line["quantity"]}},
        )
        if result.modified_count != 1:
            for prev in reserved:
                db.products.update_one(
                    {"product_id": prev["product_id"]},
                    {"$inc": {"stock": prev["quantity"]}},
                )
            return False, line["product_name"]
        reserved.append(line)
    return True, ""


def restore_stock(items):
    for line in items:
        db.products.update_one(
            {"product_id": line.get("product_id")},
            {"$inc": {"stock": int(line.get("quantity", 0))}},
        )


def create_order_record(customer_id, items, status="Placed"):
    order_doc = {
        "order_id": generate_next_id(db.orders, "order_id", "O", 1001),
        "customer_id": customer_id,
        "order_date": datetime.utcnow(),
        "items": items,
        "total_amount": round(sum(i["subtotal"] for i in items), 2),
        "status": status,
    }
    db.orders.insert_one(order_doc)
    return order_doc


def get_logged_in_user():
    user_session = session.get("client_user")
    if not isinstance(user_session, dict):
        return None

    email = str(user_session.get("email", "")).strip().lower()
    if not email:
        return None

    user = db.users.find_one({"email": email}, {"_id": 0, "password_hash": 0})
    if not user:
        session.pop("client_user", None)
        return None

    return user


def build_stripe_line_items(items):
    line_items = []
    for item in items:
        unit_amount = int(round(float(item.get("price", 0)) * 100))
        if unit_amount <= 0:
            continue
        line_items.append(
            {
                "price_data": {
                    "currency": Config.STRIPE_CURRENCY.lower(),
                    "unit_amount": unit_amount,
                    "product_data": {"name": item.get("product_name", "Product")},
                },
                "quantity": int(item.get("quantity", 1)),
            }
        )
    return line_items


@app.template_filter("currency")
def currency_filter(value):
    return f"Rs. {float(value or 0):,.2f}"


@app.template_filter("fmtdate")
def fmt_date_filter(value):
    if not value:
        return "-"
    return value.strftime("%d %b %Y, %I:%M %p") if isinstance(value, datetime) else str(value)


@app.context_processor
def inject_globals():
    client_user = get_logged_in_user()
    return {
        "ORDER_STATUSES": ORDER_STATUSES,
        "status_badge": build_status_badge,
        "APP_TITLE": "E-Commerce Product & Order Management System",
        "CURRENT_YEAR": datetime.now().year,
        "CLIENT_CART_COUNT": get_cart_count(),
        "CLIENT_USER": client_user,
        "STRIPE_ENABLED": bool(Config.STRIPE_PUBLIC_KEY and Config.STRIPE_SECRET_KEY),
        "STRIPE_PUBLIC_KEY": Config.STRIPE_PUBLIC_KEY,
    }


def aggregate_sales_per_product(limit=None):
    pipeline = [
        {"$unwind": "$items"},
        {
            "$group": {
                "_id": {
                    "product_id": "$items.product_id",
                    "product_name": "$items.product_name",
                },
                "total_quantity_sold": {"$sum": "$items.quantity"},
                "total_sales": {"$sum": "$items.subtotal"},
            }
        },
        {
            "$project": {
                "_id": 0,
                "product_id": "$_id.product_id",
                "product_name": "$_id.product_name",
                "total_quantity_sold": 1,
                "total_sales": 1,
            }
        },
        {"$sort": {"total_quantity_sold": -1, "total_sales": -1}},
    ]
    if limit:
        pipeline.append({"$limit": int(limit)})
    rows = list(db.orders.aggregate(pipeline))
    for row in rows:
        row["total_sales"] = round(float(row.get("total_sales", 0)), 2)
    return rows


def aggregate_total_revenue():
    doc = next(iter(db.orders.aggregate([{"$group": {"_id": None, "total": {"$sum": "$total_amount"}}}])), None)
    return round(float(doc.get("total", 0)), 2) if doc else 0.0


def aggregate_orders_per_customer():
    pipeline = [
        {
            "$group": {
                "_id": "$customer_id",
                "orders_count": {"$sum": 1},
                "total_spent": {"$sum": "$total_amount"},
            }
        },
        {
            "$lookup": {
                "from": "customers",
                "localField": "_id",
                "foreignField": "customer_id",
                "as": "customer",
            }
        },
        {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
        {
            "$project": {
                "_id": 0,
                "customer_id": "$_id",
                "customer_name": {"$ifNull": ["$customer.name", "Unknown Customer"]},
                "email": {"$ifNull": ["$customer.email", "-"]},
                "orders_count": 1,
                "total_spent": 1,
            }
        },
        {"$sort": {"orders_count": -1, "total_spent": -1}},
    ]
    rows = list(db.orders.aggregate(pipeline))
    for row in rows:
        row["total_spent"] = round(float(row.get("total_spent", 0)), 2)
    return rows


def seed_database(reset=False):
    if reset:
        db.orders.delete_many({})
        db.customers.delete_many({})
        db.products.delete_many({})

    sample_products = [
        {"product_id": "P101", "name": "Wireless Mouse", "category": "Electronics", "brand": "LogiTech", "price": 799, "stock": 40, "description": "Ergonomic wireless mouse with silent clicks.", "image_url": "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46", "created_at": datetime.utcnow()},
        {"product_id": "P102", "name": "Mechanical Keyboard", "category": "Electronics", "brand": "KeyChron", "price": 2899, "stock": 30, "description": "RGB mechanical keyboard with hot-swappable keys.", "image_url": "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae", "created_at": datetime.utcnow()},
        {"product_id": "P103", "name": "Noise Cancelling Headphones", "category": "Electronics", "brand": "Sony", "price": 6999, "stock": 25, "description": "Over-ear wireless headphones with ANC.", "image_url": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e", "created_at": datetime.utcnow()},
        {"product_id": "P104", "name": "Running Shoes", "category": "Fashion", "brand": "Nike", "price": 3599, "stock": 35, "description": "Breathable running shoes for daily workouts.", "image_url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff", "created_at": datetime.utcnow()},
        {"product_id": "P105", "name": "Smart Water Bottle", "category": "Lifestyle", "brand": "Hydra", "price": 1499, "stock": 18, "description": "Tracks hydration and reminds you to drink water.", "image_url": "https://images.unsplash.com/photo-1602143407151-7111542de6e8", "created_at": datetime.utcnow()},
        {"product_id": "P106", "name": "Backpack 32L", "category": "Travel", "brand": "SkyBag", "price": 2299, "stock": 22, "description": "Water-resistant backpack with laptop sleeve.", "image_url": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee", "created_at": datetime.utcnow()},
        {"product_id": "P107", "name": "LED Desk Lamp", "category": "Home", "brand": "Philips", "price": 1199, "stock": 28, "description": "Adjustable LED lamp with touch dimmer.", "image_url": "https://images.unsplash.com/photo-1505691938895-1758d7feb511", "created_at": datetime.utcnow()},
        {"product_id": "P108", "name": "Ceramic Coffee Mug", "category": "Home", "brand": "HomeNest", "price": 399, "stock": 80, "description": "Microwave-safe ceramic mug (350 ml).", "image_url": "https://images.unsplash.com/photo-1515442261605-65987783cb6a", "created_at": datetime.utcnow()},
        {"product_id": "P109", "name": "Fitness Band", "category": "Electronics", "brand": "FitBit", "price": 2499, "stock": 14, "description": "Tracks heart rate, sleep, and daily steps.", "image_url": "https://images.unsplash.com/photo-1576243345690-4e4b79b63288", "created_at": datetime.utcnow()},
        {"product_id": "P110", "name": "Notebook Pack", "category": "Stationery", "brand": "ClassMate", "price": 299, "stock": 120, "description": "Pack of 4 ruled notebooks for college use.", "image_url": "https://images.unsplash.com/photo-1455390582262-044cdead277a", "created_at": datetime.utcnow()},
    ]

    sample_customers = [
        {"customer_id": "C101", "name": "Rahul Sharma", "email": "rahul.sharma@example.com", "phone": "9876543210", "address": "Salt Lake Sector V", "city": "Kolkata", "joined_at": datetime.utcnow() - timedelta(days=120)},
        {"customer_id": "C102", "name": "Ananya Sen", "email": "ananya.sen@example.com", "phone": "9903011122", "address": "Gariahat Road", "city": "Kolkata", "joined_at": datetime.utcnow() - timedelta(days=90)},
        {"customer_id": "C103", "name": "Vikram Rao", "email": "vikram.rao@example.com", "phone": "9810012345", "address": "HSR Layout", "city": "Bengaluru", "joined_at": datetime.utcnow() - timedelta(days=75)},
        {"customer_id": "C104", "name": "Priya Nair", "email": "priya.nair@example.com", "phone": "9845012345", "address": "Baner Main Road", "city": "Pune", "joined_at": datetime.utcnow() - timedelta(days=60)},
        {"customer_id": "C105", "name": "Arjun Mehta", "email": "arjun.mehta@example.com", "phone": "9899988888", "address": "Dwarka Sector 10", "city": "New Delhi", "joined_at": datetime.utcnow() - timedelta(days=45)},
    ]

    order_blueprints = [
        {"customer_id": "C101", "status": "Placed", "items": [("P101", 2), ("P103", 1)]},
        {"customer_id": "C102", "status": "Packed", "items": [("P104", 1), ("P108", 3)]},
        {"customer_id": "C103", "status": "Shipped", "items": [("P102", 1), ("P109", 1)]},
        {"customer_id": "C104", "status": "Delivered", "items": [("P106", 1), ("P110", 5)]},
        {"customer_id": "C105", "status": "Cancelled", "items": [("P105", 2), ("P107", 1)]},
        {"customer_id": "C101", "status": "Delivered", "items": [("P102", 1), ("P104", 1)]},
        {"customer_id": "C102", "status": "Shipped", "items": [("P103", 1), ("P108", 2), ("P110", 2)]},
        {"customer_id": "C103", "status": "Placed", "items": [("P101", 1), ("P105", 1)]},
        {"customer_id": "C104", "status": "Delivered", "items": [("P107", 2), ("P109", 1)]},
        {"customer_id": "C105", "status": "Packed", "items": [("P106", 1), ("P104", 2)]},
    ]

    added_products = added_customers = added_orders = 0

    if db.products.count_documents({}) == 0:
        db.products.insert_many(sample_products)
        added_products = len(sample_products)

    if db.customers.count_documents({}) == 0:
        db.customers.insert_many(sample_customers)
        added_customers = len(sample_customers)

    if db.orders.count_documents({}) == 0:
        order_number = 1001
        for idx, seed in enumerate(order_blueprints):
            items = []
            total = 0.0
            valid = True
            for pid, qty in seed["items"]:
                product = db.products.find_one({"product_id": pid})
                if not product or product.get("stock", 0) < qty:
                    valid = False
                    break
                subtotal = round(float(product.get("price", 0)) * qty, 2)
                total += subtotal
                items.append({"product_id": pid, "product_name": product.get("name", "Unknown"), "quantity": qty, "price": float(product.get("price", 0)), "subtotal": subtotal})
            if not valid:
                continue
            for item in items:
                db.products.update_one({"product_id": item["product_id"]}, {"$inc": {"stock": -item["quantity"]}})
            db.orders.insert_one({"order_id": f"O{order_number}", "customer_id": seed["customer_id"], "order_date": datetime.utcnow() - timedelta(days=idx * 2), "items": items, "total_amount": round(total, 2), "status": seed["status"], "payment_method": "Seeded", "payment_status": "Paid"})
            order_number += 1
            added_orders += 1

    return {"products": added_products, "customers": added_customers, "orders": added_orders}

@app.route("/")
def home():
    featured_products = list(
        db.products.find({}, {"_id": 0, "product_id": 1, "name": 1, "price": 1, "image_url": 1})
        .sort("created_at", DESCENDING)
        .limit(6)
    )
    return render_template("home.html", featured_products=featured_products)


@app.route("/admin")
@app.route("/dashboard")
def dashboard():
    total_products = db.products.count_documents({})
    total_customers = db.customers.count_documents({})
    total_orders = db.orders.count_documents({})
    total_revenue = aggregate_total_revenue()

    sales_per_product = aggregate_sales_per_product(limit=10)
    most_purchased = sales_per_product[0] if sales_per_product else None
    low_stock_count = db.products.count_documents({"stock": {"$lt": int(Config.LOW_STOCK_THRESHOLD)}})

    recent_orders = list(
        db.orders.aggregate(
            [
                {"$lookup": {"from": "customers", "localField": "customer_id", "foreignField": "customer_id", "as": "customer"}},
                {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
                {"$project": {"_id": 0, "order_id": 1, "customer_name": {"$ifNull": ["$customer.name", "Unknown"]}, "customer_email": {"$ifNull": ["$customer.email", "-"]}, "order_date": 1, "total_amount": 1, "status": 1}},
                {"$sort": {"order_date": -1}},
                {"$limit": 8},
            ]
        )
    )

    status_rows = list(db.orders.aggregate([{"$group": {"_id": "$status", "count": {"$sum": 1}}}, {"$sort": {"count": -1}}]))

    sales_chart_data = {
        "labels": [row["product_name"] for row in sales_per_product],
        "quantities": [row["total_quantity_sold"] for row in sales_per_product],
        "sales": [row["total_sales"] for row in sales_per_product],
    }
    status_chart_data = {
        "labels": [row.get("_id", "Unknown") for row in status_rows],
        "counts": [row.get("count", 0) for row in status_rows],
    }

    return render_template(
        "dashboard.html",
        total_products=total_products,
        total_customers=total_customers,
        total_orders=total_orders,
        total_revenue=total_revenue,
        most_purchased=most_purchased,
        low_stock_count=low_stock_count,
        recent_orders=recent_orders,
        sales_chart_data=sales_chart_data,
        status_chart_data=status_chart_data,
    )


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if get_logged_in_user():
        return redirect(url_for("client_products"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = normalize_phone(request.form.get("phone", ""))
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        errors = []
        if not name:
            errors.append("Name is required.")
        if not email:
            errors.append("Email is required.")
        elif not validate_email(email):
            errors.append("Please enter a valid email.")
        if not phone:
            errors.append("Phone is required.")
        if not address:
            errors.append("Address is required.")
        if not city:
            errors.append("City is required.")
        if len(password) < 6:
            errors.append("Password must be at least 6 characters.")
        if password != confirm_password:
            errors.append("Passwords do not match.")

        if db.users.find_one({"email": email}):
            errors.append("This email is already registered. Please login.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template(
                "signup.html",
                form_data={"name": name, "email": email, "phone": phone, "address": address, "city": city},
            )

        customer = db.customers.find_one({"email": email})
        if customer:
            customer_id = customer["customer_id"]
            db.customers.update_one(
                {"customer_id": customer_id},
                {"$set": {"name": name, "phone": phone, "address": address, "city": city}},
            )
        else:
            customer_id = generate_next_id(db.customers, "customer_id", "C", 101)
            db.customers.insert_one(
                {
                    "customer_id": customer_id,
                    "name": name,
                    "email": email,
                    "phone": phone,
                    "address": address,
                    "city": city,
                    "joined_at": datetime.utcnow(),
                }
            )

        user_doc = {
            "user_id": generate_next_id(db.users, "user_id", "U", 101),
            "name": name,
            "email": email,
            "password_hash": generate_password_hash(password),
            "customer_id": customer_id,
            "created_at": datetime.utcnow(),
        }

        try:
            db.users.insert_one(user_doc)
        except DuplicateKeyError:
            flash("This email is already registered. Please login.", "danger")
            return redirect(url_for("login"))

        session["client_user"] = {
            "user_id": user_doc["user_id"],
            "name": user_doc["name"],
            "email": user_doc["email"],
            "customer_id": user_doc["customer_id"],
        }
        flash("Signup successful. Welcome!", "success")
        return redirect(url_for("client_products"))

    return render_template("signup.html", form_data={})


@app.route("/login", methods=["GET", "POST"])
def login():
    if get_logged_in_user():
        return redirect(url_for("client_products"))

    next_url = request.args.get("next", "")
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        next_url = request.form.get("next", "").strip()

        user = db.users.find_one({"email": email})
        if not user or not check_password_hash(user.get("password_hash", ""), password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html", next_url=next_url)

        session["client_user"] = {
            "user_id": user.get("user_id"),
            "name": user.get("name"),
            "email": user.get("email"),
            "customer_id": user.get("customer_id"),
        }
        flash("Login successful.", "success")
        if next_url.startswith("/"):
            return redirect(next_url)
        return redirect(url_for("client_products"))

    return render_template("login.html", next_url=next_url)


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("client_user", None)
    flash("You have been logged out.", "warning")
    return redirect(url_for("home"))


@app.route("/products")
def products():
    query_text = request.args.get("q", "").strip()
    selected_category = request.args.get("category", "").strip()

    query = {}
    if query_text:
        regex = {"$regex": query_text, "$options": "i"}
        query["$or"] = [{"product_id": regex}, {"name": regex}, {"category": regex}, {"brand": regex}]
    if selected_category:
        query["category"] = selected_category

    products_data = list(db.products.find(query).sort("created_at", DESCENDING))
    categories = sorted(db.products.distinct("category"))

    return render_template("products.html", products=products_data, categories=categories, query_text=query_text, selected_category=selected_category)


@app.route("/products/new", methods=["GET", "POST"])
def add_product():
    if request.method == "POST":
        product_id = request.form.get("product_id", "").strip() or generate_next_id(db.products, "product_id", "P", 101)
        name = request.form.get("name", "").strip()
        category = request.form.get("category", "").strip()
        brand = request.form.get("brand", "").strip()
        description = request.form.get("description", "").strip()
        image_url = request.form.get("image_url", "").strip()

        price, price_error = parse_positive_float(request.form.get("price", ""), "Price")
        stock, stock_error = parse_non_negative_int(request.form.get("stock", ""), "Stock")

        errors = []
        if not name:
            errors.append("Product name is required.")
        if not category:
            errors.append("Category is required.")
        if not brand:
            errors.append("Brand is required.")
        if price_error:
            errors.append(price_error)
        if stock_error:
            errors.append(stock_error)

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template("product_form.html", form_title="Add Product", submit_label="Create Product", product={"product_id": product_id, "name": name, "category": category, "brand": brand, "price": request.form.get("price", ""), "stock": request.form.get("stock", ""), "description": description, "image_url": image_url}, is_edit=False)

        try:
            db.products.insert_one({"product_id": product_id, "name": name, "category": category, "brand": brand, "price": price, "stock": stock, "description": description, "image_url": image_url, "created_at": datetime.utcnow()})
            flash(f"Product {product_id} created successfully.", "success")
            return redirect(url_for("products"))
        except DuplicateKeyError:
            flash("Product ID already exists. Please try again.", "danger")

    next_id = generate_next_id(db.products, "product_id", "P", 101)
    return render_template("product_form.html", form_title="Add Product", submit_label="Create Product", product={"product_id": next_id}, is_edit=False)


@app.route("/products/<product_id>")
def product_detail(product_id):
    product = db.products.find_one({"product_id": product_id})
    if not product:
        return render_template("404.html"), 404

    sales_row = list(
        db.orders.aggregate(
            [
                {"$unwind": "$items"},
                {"$match": {"items.product_id": product_id}},
                {"$group": {"_id": "$items.product_id", "total_sold": {"$sum": "$items.quantity"}, "total_sales": {"$sum": "$items.subtotal"}}},
            ]
        )
    )
    sales_info = sales_row[0] if sales_row else {"total_sold": 0, "total_sales": 0}

    recent_orders = list(db.orders.find({"items.product_id": product_id}, {"order_id": 1, "order_date": 1, "status": 1}).sort("order_date", DESCENDING).limit(5))

    return render_template("product_detail.html", product=product, sales_info=sales_info, recent_orders=recent_orders)


@app.route("/products/<product_id>/edit", methods=["GET", "POST"])
def edit_product(product_id):
    product = db.products.find_one({"product_id": product_id})
    if not product:
        return render_template("404.html"), 404

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        category = request.form.get("category", "").strip()
        brand = request.form.get("brand", "").strip()
        description = request.form.get("description", "").strip()
        image_url = request.form.get("image_url", "").strip()

        price, price_error = parse_positive_float(request.form.get("price", ""), "Price")
        stock, stock_error = parse_non_negative_int(request.form.get("stock", ""), "Stock")

        errors = []
        if not name:
            errors.append("Product name is required.")
        if not category:
            errors.append("Category is required.")
        if not brand:
            errors.append("Brand is required.")
        if price_error:
            errors.append(price_error)
        if stock_error:
            errors.append(stock_error)

        if errors:
            for err in errors:
                flash(err, "danger")
            product.update({"name": name, "category": category, "brand": brand, "price": request.form.get("price", ""), "stock": request.form.get("stock", ""), "description": description, "image_url": image_url})
            return render_template("product_form.html", form_title="Edit Product", submit_label="Update Product", product=product, is_edit=True)

        db.products.update_one({"product_id": product_id}, {"$set": {"name": name, "category": category, "brand": brand, "price": price, "stock": stock, "description": description, "image_url": image_url}})
        flash(f"Product {product_id} updated successfully.", "success")
        return redirect(url_for("products"))

    return render_template("product_form.html", form_title="Edit Product", submit_label="Update Product", product=product, is_edit=True)


@app.route("/products/<product_id>/delete", methods=["POST"])
def delete_product(product_id):
    if db.orders.count_documents({"items.product_id": product_id}) > 0:
        flash("Product cannot be deleted because it is linked with existing orders.", "warning")
        return redirect(url_for("products"))

    result = db.products.delete_one({"product_id": product_id})
    flash(f"Product {product_id} deleted." if result.deleted_count else "Product not found.", "success" if result.deleted_count else "danger")
    return redirect(url_for("products"))


@app.route("/customers")
def customers():
    query_text = request.args.get("q", "").strip()
    query = {}
    if query_text:
        regex = {"$regex": query_text, "$options": "i"}
        query["$or"] = [{"customer_id": regex}, {"name": regex}, {"email": regex}, {"phone": regex}, {"city": regex}]
    customers_data = list(db.customers.find(query).sort("joined_at", DESCENDING))
    return render_template("customers.html", customers=customers_data, query_text=query_text)


@app.route("/customers/new", methods=["GET", "POST"])
def add_customer():
    if request.method == "POST":
        customer_id = request.form.get("customer_id", "").strip() or generate_next_id(db.customers, "customer_id", "C", 101)
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = normalize_phone(request.form.get("phone", ""))
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "").strip()

        errors = []
        if not name:
            errors.append("Customer name is required.")
        if not email:
            errors.append("Customer email is required.")
        elif not validate_email(email):
            errors.append("Please enter a valid email address.")
        if not phone:
            errors.append("Phone number is required.")
        if not address:
            errors.append("Address is required.")
        if not city:
            errors.append("City is required.")

        if db.customers.count_documents({"email": email}) > 0:
            errors.append("This email is already used by another customer.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template("customer_form.html", form_title="Add Customer", submit_label="Create Customer", customer={"customer_id": customer_id, "name": name, "email": email, "phone": phone, "address": address, "city": city}, is_edit=False)

        try:
            db.customers.insert_one({"customer_id": customer_id, "name": name, "email": email, "phone": phone, "address": address, "city": city, "joined_at": datetime.utcnow()})
            flash(f"Customer {customer_id} created successfully.", "success")
            return redirect(url_for("customers"))
        except DuplicateKeyError:
            flash("Customer ID already exists. Please try again.", "danger")

    next_id = generate_next_id(db.customers, "customer_id", "C", 101)
    return render_template("customer_form.html", form_title="Add Customer", submit_label="Create Customer", customer={"customer_id": next_id}, is_edit=False)


@app.route("/customers/<customer_id>")
def customer_detail(customer_id):
    customer_docs = list(
        db.customers.aggregate(
            [
                {"$match": {"customer_id": customer_id}},
                {"$lookup": {"from": "orders", "localField": "customer_id", "foreignField": "customer_id", "as": "orders"}},
                {"$addFields": {"total_spent": {"$sum": "$orders.total_amount"}, "order_count": {"$size": "$orders"}}},
            ]
        )
    )
    if not customer_docs:
        return render_template("404.html"), 404

    customer = customer_docs[0]
    customer_orders = sorted(customer.get("orders", []), key=lambda row: row.get("order_date", datetime.min), reverse=True)
    return render_template("customer_detail.html", customer=customer, customer_orders=customer_orders)


@app.route("/customers/<customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    customer = db.customers.find_one({"customer_id": customer_id})
    if not customer:
        return render_template("404.html"), 404

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = normalize_phone(request.form.get("phone", ""))
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "").strip()

        errors = []
        if not name:
            errors.append("Customer name is required.")
        if not email:
            errors.append("Customer email is required.")
        elif not validate_email(email):
            errors.append("Please enter a valid email address.")
        if not phone:
            errors.append("Phone number is required.")
        if not address:
            errors.append("Address is required.")
        if not city:
            errors.append("City is required.")
        if db.customers.find_one({"email": email, "customer_id": {"$ne": customer_id}}):
            errors.append("This email is already used by another customer.")

        if errors:
            for err in errors:
                flash(err, "danger")
            customer.update({"name": name, "email": email, "phone": phone, "address": address, "city": city})
            return render_template("customer_form.html", form_title="Edit Customer", submit_label="Update Customer", customer=customer, is_edit=True)

        db.customers.update_one({"customer_id": customer_id}, {"$set": {"name": name, "email": email, "phone": phone, "address": address, "city": city}})
        flash(f"Customer {customer_id} updated successfully.", "success")
        return redirect(url_for("customers"))

    return render_template("customer_form.html", form_title="Edit Customer", submit_label="Update Customer", customer=customer, is_edit=True)


@app.route("/customers/<customer_id>/delete", methods=["POST"])
def delete_customer(customer_id):
    if db.orders.count_documents({"customer_id": customer_id}) > 0:
        flash("Customer cannot be deleted because existing orders are linked to this profile.", "warning")
        return redirect(url_for("customers"))

    result = db.customers.delete_one({"customer_id": customer_id})
    flash(f"Customer {customer_id} deleted." if result.deleted_count else "Customer not found.", "success" if result.deleted_count else "danger")
    return redirect(url_for("customers"))


def parse_order_form():
    customer_id = request.form.get("customer_id", "").strip()
    status = request.form.get("status", "Placed").strip()
    product_ids = [v.strip() for v in request.form.getlist("item_product_id")]
    quantities = [v.strip() for v in request.form.getlist("item_quantity")]

    errors = []
    if not customer_id:
        errors.append("Please select a customer.")
    if status not in ORDER_STATUSES:
        errors.append("Invalid order status selected.")
    if not product_ids or all(not pid for pid in product_ids):
        errors.append("Please add at least one product item.")
    if len(product_ids) != len(quantities):
        errors.append("Invalid order rows submitted.")
        return customer_id, status, [], errors

    qty_by_product = {}
    for idx, (pid, qty_raw) in enumerate(zip(product_ids, quantities), start=1):
        if not pid:
            errors.append(f"Row {idx}: Product is required.")
            continue
        qty, qty_error = parse_positive_int(qty_raw, f"Row {idx} quantity")
        if qty_error:
            errors.append(qty_error)
            continue
        qty_by_product[pid] = qty_by_product.get(pid, 0) + qty

    if errors:
        return customer_id, status, [], errors

    items, item_errors = build_items_from_quantity_map(qty_by_product)
    return customer_id, status, items, errors + item_errors


@app.route("/orders")
def orders():
    query_text = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "").strip()

    match_stage = {}
    if query_text:
        match_stage["order_id"] = {"$regex": query_text, "$options": "i"}
    if status_filter:
        match_stage["status"] = status_filter

    pipeline = []
    if match_stage:
        pipeline.append({"$match": match_stage})
    pipeline.extend(
        [
            {"$lookup": {"from": "customers", "localField": "customer_id", "foreignField": "customer_id", "as": "customer"}},
            {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
            {"$project": {"_id": 0, "order_id": 1, "customer_id": 1, "customer_name": {"$ifNull": ["$customer.name", "Unknown"]}, "customer_email": {"$ifNull": ["$customer.email", "-"]}, "order_date": 1, "total_amount": 1, "status": 1, "payment_method": 1, "payment_status": 1}},
            {"$sort": {"order_date": -1}},
        ]
    )

    rows = list(db.orders.aggregate(pipeline))
    return render_template("orders.html", orders=rows, query_text=query_text, status_filter=status_filter)


@app.route("/orders/new", methods=["GET", "POST"])
def create_order():
    customers_data = list(db.customers.find().sort("name", ASCENDING))
    products_data = list(
        db.products.find(
            {},
            {"_id": 0, "product_id": 1, "name": 1, "price": 1, "stock": 1},
        ).sort("name", ASCENDING)
    )

    if request.method == "POST":
        customer_id, status, items, errors = parse_order_form()
        if not db.customers.find_one({"customer_id": customer_id}):
            errors.append("Selected customer does not exist.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template("order_form.html", customers=customers_data, products=products_data, selected_customer_id=customer_id, selected_status=status)

        stock_ok, failed_product_name = reserve_stock(items)
        if not stock_ok:
            flash(f"Stock changed while placing order. Could not reserve {failed_product_name}.", "danger")
            return render_template("order_form.html", customers=customers_data, products=products_data, selected_customer_id=customer_id, selected_status=status)

        try:
            order_doc = create_order_record(customer_id=customer_id, items=items, status=status)
            db.orders.update_one(
                {"order_id": order_doc["order_id"]},
                {"$set": {"payment_method": "Manual Entry", "payment_status": "Pending"}},
            )
            flash(f"Order {order_doc['order_id']} created successfully.", "success")
            return redirect(url_for("orders"))
        except DuplicateKeyError:
            restore_stock(items)
            flash("Order ID conflict occurred. Please submit again.", "danger")

    return render_template("order_form.html", customers=customers_data, products=products_data, selected_customer_id="", selected_status="Placed")


@app.route("/orders/<order_id>")
def order_detail(order_id):
    pipeline = [
        {"$match": {"order_id": order_id}},
        {"$lookup": {"from": "customers", "localField": "customer_id", "foreignField": "customer_id", "as": "customer"}},
        {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
        {"$lookup": {"from": "products", "localField": "items.product_id", "foreignField": "product_id", "as": "product_docs"}},
    ]

    order = next(iter(db.orders.aggregate(pipeline)), None)
    if not order:
        return render_template("404.html"), 404

    product_map = {p.get("product_id"): p for p in order.get("product_docs", [])}
    detailed_items = []
    for item in order.get("items", []):
        prod = product_map.get(item.get("product_id"), {})
        detailed_items.append({**item, "category": prod.get("category", "N/A"), "brand": prod.get("brand", "N/A")})
    order["items"] = detailed_items

    return render_template("order_detail.html", order=order)


@app.route("/orders/<order_id>/status", methods=["POST"])
def update_order_status(order_id):
    status = request.form.get("status", "").strip()
    if status not in ORDER_STATUSES:
        flash("Invalid order status selected.", "danger")
        return redirect(url_for("order_detail", order_id=order_id))

    updated = db.orders.update_one({"order_id": order_id}, {"$set": {"status": status}})
    flash(f"Order {order_id} status updated to {status}." if updated.matched_count else "Order not found.", "success" if updated.matched_count else "danger")
    return redirect(url_for("order_detail", order_id=order_id))


@app.route("/orders/<order_id>/delete", methods=["POST"])
def delete_order(order_id):
    order = db.orders.find_one({"order_id": order_id})
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("orders"))

    for item in order.get("items", []):
        db.products.update_one({"product_id": item.get("product_id")}, {"$inc": {"stock": int(item.get("quantity", 0))}})

    db.orders.delete_one({"order_id": order_id})
    flash(f"Order {order_id} deleted and stock restored.", "warning")
    return redirect(url_for("orders"))


@app.route("/client")
def client_home():
    return redirect(url_for("client_products"))


@app.route("/client/products")
def client_products():
    query_text = request.args.get("q", "").strip()
    selected_category = request.args.get("category", "").strip()

    query = {"stock": {"$gt": 0}}
    if query_text:
        regex = {"$regex": query_text, "$options": "i"}
        query["$or"] = [{"name": regex}, {"category": regex}, {"brand": regex}, {"product_id": regex}]
    if selected_category:
        query["category"] = selected_category

    product_rows = list(db.products.find(query).sort("created_at", DESCENDING))
    categories = sorted(db.products.distinct("category"))
    return render_template(
        "client_products.html",
        products=product_rows,
        categories=categories,
        query_text=query_text,
        selected_category=selected_category,
    )


@app.route("/client/cart")
def client_cart():
    cart_map = get_session_cart()
    cart_items = []
    cart_total = 0.0

    if cart_map:
        product_rows = list(db.products.find({"product_id": {"$in": list(cart_map.keys())}}))
        product_map = {p["product_id"]: p for p in product_rows}
        missing_ids = []

        for product_id, qty in cart_map.items():
            product = product_map.get(product_id)
            if not product:
                missing_ids.append(product_id)
                continue

            price = float(product.get("price", 0))
            subtotal = round(price * qty, 2)
            cart_total += subtotal
            cart_items.append(
                {
                    "product_id": product_id,
                    "name": product.get("name", "Unknown"),
                    "brand": product.get("brand", "-"),
                    "image_url": product.get("image_url", ""),
                    "price": price,
                    "quantity": qty,
                    "stock": int(product.get("stock", 0)),
                    "subtotal": subtotal,
                    "stock_ok": qty <= int(product.get("stock", 0)),
                }
            )

        if missing_ids:
            for product_id in missing_ids:
                cart_map.pop(product_id, None)
            session["cart"] = cart_map
            flash("Some unavailable products were removed from your cart.", "warning")

    return render_template("client_cart.html", cart_items=cart_items, cart_total=round(cart_total, 2))


@app.route("/client/cart/add/<product_id>", methods=["POST"])
def client_add_to_cart(product_id):
    qty, qty_error = parse_positive_int(request.form.get("quantity", "1"), "Quantity")
    if qty_error:
        flash(qty_error, "danger")
        return redirect(request.referrer or url_for("client_products"))

    product = db.products.find_one({"product_id": product_id})
    if not product:
        flash("Product not found.", "danger")
        return redirect(request.referrer or url_for("client_products"))

    if int(product.get("stock", 0)) <= 0:
        flash("This product is currently out of stock.", "warning")
        return redirect(request.referrer or url_for("client_products"))

    cart_map = get_session_cart()
    current_qty = int(cart_map.get(product_id, 0))
    new_qty = current_qty + qty
    stock = int(product.get("stock", 0))
    if new_qty > stock:
        new_qty = stock
        flash("Quantity adjusted to available stock.", "warning")

    cart_map[product_id] = new_qty
    session["cart"] = cart_map
    flash(f"{product.get('name', 'Product')} added to cart.", "success")
    return redirect(request.referrer or url_for("client_products"))


@app.route("/client/cart/update", methods=["POST"])
def client_update_cart():
    product_ids = request.form.getlist("product_id")
    quantities = request.form.getlist("quantity")

    updated_cart = {}
    for product_id, qty_raw in zip(product_ids, quantities):
        product_id = product_id.strip()
        if not product_id:
            continue
        try:
            qty = int(qty_raw)
        except (TypeError, ValueError):
            continue
        if qty > 0:
            updated_cart[product_id] = qty

    session["cart"] = updated_cart
    flash("Cart updated successfully.", "success")
    return redirect(url_for("client_cart"))


@app.route("/client/cart/remove/<product_id>", methods=["POST"])
def client_remove_from_cart(product_id):
    cart_map = get_session_cart()
    if product_id in cart_map:
        cart_map.pop(product_id, None)
        session["cart"] = cart_map
        flash("Item removed from cart.", "warning")
    return redirect(url_for("client_cart"))


@app.route("/client/cart/clear", methods=["POST"])
def client_clear_cart():
    session["cart"] = {}
    flash("Cart cleared.", "warning")
    return redirect(url_for("client_cart"))


@app.route("/client/checkout", methods=["GET", "POST"])
def client_checkout():
    client_user = get_logged_in_user()
    if not client_user:
        flash("Please login to continue checkout.", "warning")
        return redirect(url_for("login", next=url_for("client_checkout")))

    customer = db.customers.find_one({"customer_id": client_user.get("customer_id")})
    if not customer:
        flash("Customer profile not found. Please sign up again.", "danger")
        return redirect(url_for("signup"))

    cart_map = get_session_cart()
    if not cart_map:
        flash("Your cart is empty. Add products before checkout.", "warning")
        return redirect(url_for("client_products"))

    cart_preview_items, cart_errors = build_items_from_quantity_map(cart_map)
    cart_total = round(sum(item["subtotal"] for item in cart_preview_items), 2)
    if cart_errors:
        for err in cart_errors:
            flash(err, "danger")
        return redirect(url_for("client_cart"))

    selected_payment_method = "stripe"
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = customer.get("email", client_user.get("email", "")).strip().lower()
        phone = normalize_phone(request.form.get("phone", ""))
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "").strip()
        selected_payment_method = request.form.get("payment_method", "stripe").strip().lower()

        errors = []
        if not name:
            errors.append("Name is required.")
        if not email or not validate_email(email):
            errors.append("A valid email is required for your account.")
        if not phone:
            errors.append("Phone is required.")
        if not address:
            errors.append("Address is required.")
        if not city:
            errors.append("City is required.")
        if selected_payment_method not in {"stripe", "cod"}:
            errors.append("Invalid payment method selected.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template(
                "client_checkout.html",
                cart_items=cart_preview_items,
                cart_total=cart_total,
                form_data={"name": name, "email": email, "phone": phone, "address": address, "city": city},
                email_locked=True,
                selected_payment_method=selected_payment_method,
            )

        customer_id = customer["customer_id"]
        db.customers.update_one(
            {"customer_id": customer_id},
            {"$set": {"name": name, "email": email, "phone": phone, "address": address, "city": city}},
        )

        if selected_payment_method == "cod":
            stock_ok, failed_product_name = reserve_stock(cart_preview_items)
            if not stock_ok:
                flash(f"Stock changed while placing order. Could not reserve {failed_product_name}.", "danger")
                return redirect(url_for("client_cart"))

            try:
                order_doc = create_order_record(customer_id=customer_id, items=cart_preview_items, status="Placed")
                db.orders.update_one(
                    {"order_id": order_doc["order_id"]},
                    {"$set": {"payment_method": "COD", "payment_status": "Pending Collection"}},
                )
            except DuplicateKeyError:
                restore_stock(cart_preview_items)
                flash("Could not place order due to order ID conflict. Please retry.", "danger")
                return redirect(url_for("client_cart"))

            session["cart"] = {}
            return redirect(url_for("client_order_success", order_id=order_doc["order_id"]))

        if not (Config.STRIPE_PUBLIC_KEY and Config.STRIPE_SECRET_KEY):
            flash("Online payment is not configured. Please choose Cash on Delivery.", "warning")
            return render_template(
                "client_checkout.html",
                cart_items=cart_preview_items,
                cart_total=cart_total,
                form_data={"name": name, "email": email, "phone": phone, "address": address, "city": city},
                email_locked=True,
                selected_payment_method=selected_payment_method,
            )

        line_items = build_stripe_line_items(cart_preview_items)
        if not line_items:
            flash("Could not prepare payment line items. Please review cart and try again.", "danger")
            return redirect(url_for("client_cart"))

        try:
            stripe_session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                mode="payment",
                line_items=line_items,
                customer_email=email,
                success_url=url_for("client_checkout_success", _external=True) + "?session_id={CHECKOUT_SESSION_ID}",
                cancel_url=url_for("client_checkout_cancel", _external=True),
                metadata={
                    "customer_id": customer_id,
                    "client_user_id": str(client_user.get("user_id", "")),
                },
            )
        except Exception as exc:
            flash(f"Could not start payment: {exc}", "danger")
            return render_template(
                "client_checkout.html",
                cart_items=cart_preview_items,
                cart_total=cart_total,
                form_data={"name": name, "email": email, "phone": phone, "address": address, "city": city},
                email_locked=True,
                selected_payment_method=selected_payment_method,
            )

        try:
            db.checkout_sessions.insert_one(
                {
                    "session_id": stripe_session.id,
                    "customer_id": customer_id,
                    "items": cart_preview_items,
                    "total_amount": cart_total,
                    "status": "created",
                    "payment_method": "Stripe",
                    "created_at": datetime.utcnow(),
                }
            )
        except DuplicateKeyError:
            db.checkout_sessions.update_one(
                {"session_id": stripe_session.id},
                {
                    "$set": {
                        "customer_id": customer_id,
                        "items": cart_preview_items,
                        "total_amount": cart_total,
                        "status": "created",
                        "payment_method": "Stripe",
                        "updated_at": datetime.utcnow(),
                    }
                },
            )

        return redirect(stripe_session.url)

    return render_template(
        "client_checkout.html",
        cart_items=cart_preview_items,
        cart_total=cart_total,
        form_data={
            "name": customer.get("name", client_user.get("name", "")),
            "email": customer.get("email", client_user.get("email", "")),
            "phone": customer.get("phone", ""),
            "address": customer.get("address", ""),
            "city": customer.get("city", ""),
        },
        email_locked=True,
        selected_payment_method=selected_payment_method,
    )


@app.route("/client/checkout/success")
def client_checkout_success():
    client_user = get_logged_in_user()
    if not client_user:
        flash("Please login to continue.", "warning")
        return redirect(url_for("login", next=request.full_path))

    session_id = request.args.get("session_id", "").strip()
    if not session_id:
        flash("Missing payment session. Please try checkout again.", "danger")
        return redirect(url_for("client_checkout"))

    existing_order = db.orders.find_one({"payment_session_id": session_id}, {"order_id": 1, "_id": 0})
    if existing_order:
        session["cart"] = {}
        return redirect(url_for("client_order_success", order_id=existing_order["order_id"]))

    pending_checkout = db.checkout_sessions.find_one({"session_id": session_id})
    if not pending_checkout:
        flash("Payment session not found. Please contact support if you were charged.", "danger")
        return redirect(url_for("client_orders"))

    if pending_checkout.get("customer_id") != client_user.get("customer_id"):
        flash("This payment session does not belong to your account.", "danger")
        return redirect(url_for("client_orders"))

    try:
        stripe_session = stripe.checkout.Session.retrieve(session_id)
    except Exception as exc:
        flash(f"Could not verify payment: {exc}", "danger")
        return redirect(url_for("client_orders"))

    if stripe_session.get("payment_status") != "paid":
        flash("Payment was not completed. You can try again.", "warning")
        return redirect(url_for("client_checkout"))

    items = pending_checkout.get("items", [])
    stock_ok, failed_product_name = reserve_stock(items)
    if not stock_ok:
        db.checkout_sessions.update_one(
            {"session_id": session_id},
            {"$set": {"status": "stock_failed", "updated_at": datetime.utcnow()}},
        )
        flash(
            f"Payment succeeded but stock changed for {failed_product_name}. Please contact support.",
            "danger",
        )
        return redirect(url_for("client_orders"))

    try:
        order_doc = create_order_record(
            customer_id=pending_checkout["customer_id"],
            items=items,
            status="Placed",
        )
    except DuplicateKeyError:
        restore_stock(items)
        flash("Could not finalize your paid order due to ID conflict. Please contact support.", "danger")
        return redirect(url_for("client_orders"))

    db.orders.update_one(
        {"order_id": order_doc["order_id"]},
        {
            "$set": {
                "payment_method": "Stripe",
                "payment_status": "Paid",
                "payment_session_id": session_id,
            }
        },
    )
    db.checkout_sessions.update_one(
        {"session_id": session_id},
        {
            "$set": {
                "status": "processed",
                "order_id": order_doc["order_id"],
                "updated_at": datetime.utcnow(),
            }
        },
    )
    session["cart"] = {}
    return redirect(url_for("client_order_success", order_id=order_doc["order_id"]))


@app.route("/client/checkout/cancel")
def client_checkout_cancel():
    flash("Payment cancelled. Your cart is still saved.", "warning")
    return redirect(url_for("client_checkout"))


@app.route("/client/order-success/<order_id>")
def client_order_success(order_id):
    client_user = get_logged_in_user()
    if not client_user:
        flash("Please login to view your order.", "warning")
        return redirect(url_for("login", next=url_for("client_order_success", order_id=order_id)))

    order = next(
        iter(
            db.orders.aggregate(
                [
                    {"$match": {"order_id": order_id}},
                    {"$lookup": {"from": "customers", "localField": "customer_id", "foreignField": "customer_id", "as": "customer"}},
                    {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
                ]
            )
        ),
        None,
    )
    if not order:
        return render_template("404.html"), 404
    if order.get("customer_id") != client_user.get("customer_id"):
        flash("You are not allowed to view this order.", "danger")
        return redirect(url_for("client_orders"))
    return render_template("client_order_success.html", order=order)


@app.route("/client/orders")
def client_orders():
    client_user = get_logged_in_user()
    email = request.args.get("email", "").strip().lower()
    customer = None
    orders_data = []

    if client_user:
        customer = db.customers.find_one({"customer_id": client_user.get("customer_id")})
        if customer:
            email = customer.get("email", "")
            orders_data = list(db.orders.find({"customer_id": customer["customer_id"]}).sort("order_date", DESCENDING))
    elif email:
        customer = db.customers.find_one({"email": email})
        if customer:
            orders_data = list(db.orders.find({"customer_id": customer["customer_id"]}).sort("order_date", DESCENDING))
        else:
            flash("No customer found for this email.", "warning")

    return render_template("client_orders.html", email=email, customer=customer, orders=orders_data, logged_in=bool(client_user))


@app.route("/reports")
def reports():
    threshold_raw = request.args.get("threshold", str(Config.LOW_STOCK_THRESHOLD)).strip()
    threshold, threshold_error = parse_non_negative_int(threshold_raw, "Threshold")
    if threshold_error:
        threshold = Config.LOW_STOCK_THRESHOLD
        flash("Invalid threshold provided. Default value is used.", "warning")

    sales_per_product = aggregate_sales_per_product()
    most_purchased = sales_per_product[0] if sales_per_product else None
    total_revenue = aggregate_total_revenue()
    orders_per_customer = aggregate_orders_per_customer()
    top_customer = max(orders_per_customer, key=lambda row: row.get("total_spent", 0), default=None)
    low_stock_products = list(db.products.find({"stock": {"$lt": threshold}}).sort("stock", ASCENDING))

    # Extra pipelines I added while preparing for DBMS viva/demo.
    sales_by_category = list(
        db.orders.aggregate(
            [
                {"$unwind": "$items"},
                {"$lookup": {"from": "products", "localField": "items.product_id", "foreignField": "product_id", "as": "product"}},
                {"$unwind": {"path": "$product", "preserveNullAndEmptyArrays": True}},
                {
                    "$group": {
                        "_id": {"$ifNull": ["$product.category", "Unknown"]},
                        "total_quantity": {"$sum": "$items.quantity"},
                        "total_sales": {"$sum": "$items.subtotal"},
                    }
                },
                {"$project": {"_id": 0, "category": "$_id", "total_quantity": 1, "total_sales": 1}},
                {"$sort": {"total_sales": -1}},
            ]
        )
    )
    for row in sales_by_category:
        row["total_sales"] = round(float(row.get("total_sales", 0)), 2)

    # Lookup example 1: order summary with customer details.
    lookup_order_customers = list(
        db.orders.aggregate(
            [
                {"$lookup": {"from": "customers", "localField": "customer_id", "foreignField": "customer_id", "as": "customer"}},
                {"$unwind": {"path": "$customer", "preserveNullAndEmptyArrays": True}},
                {
                    "$project": {
                        "_id": 0,
                        "order_id": 1,
                        "customer_id": 1,
                        "customer_name": {"$ifNull": ["$customer.name", "Unknown"]},
                        "customer_email": {"$ifNull": ["$customer.email", "-"]},
                        "order_date": 1,
                        "total_amount": 1,
                        "status": 1,
                    }
                },
                {"$sort": {"order_date": -1}},
                {"$limit": 20},
            ]
        )
    )

    # Lookup example 2: item-level rows joined with product details.
    lookup_order_items = list(
        db.orders.aggregate(
            [
                {"$unwind": "$items"},
                {"$lookup": {"from": "products", "localField": "items.product_id", "foreignField": "product_id", "as": "product"}},
                {"$unwind": {"path": "$product", "preserveNullAndEmptyArrays": True}},
                {
                    "$project": {
                        "_id": 0,
                        "order_id": 1,
                        "product_id": "$items.product_id",
                        "product_name": "$items.product_name",
                        "category": {"$ifNull": ["$product.category", "N/A"]},
                        "brand": {"$ifNull": ["$product.brand", "N/A"]},
                        "quantity": "$items.quantity",
                        "price": "$items.price",
                        "subtotal": "$items.subtotal",
                    }
                },
                {"$sort": {"order_id": -1}},
                {"$limit": 40},
            ]
        )
    )

    return render_template(
        "reports.html",
        sales_per_product=sales_per_product,
        most_purchased=most_purchased,
        total_revenue=total_revenue,
        orders_per_customer=orders_per_customer,
        top_customer=top_customer,
        low_stock_products=low_stock_products,
        threshold=threshold,
        sales_by_category=sales_by_category,
        lookup_order_customers=lookup_order_customers,
        lookup_order_items=lookup_order_items,
    )


@app.route("/reports/export/sales.csv")
def export_sales_report_csv():
    rows = aggregate_sales_per_product()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["product_id", "product_name", "total_quantity_sold", "total_sales"])
    for row in rows:
        writer.writerow([row.get("product_id"), row.get("product_name"), row.get("total_quantity_sold", 0), row.get("total_sales", 0)])

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=sales_report.csv"
    response.headers["Content-Type"] = "text/csv"
    return response


@app.route("/seed", methods=["POST"])
def seed_route():
    reset = request.form.get("reset") == "1"
    summary = seed_database(reset=reset)
    flash(f"Seed completed. Added Products: {summary['products']}, Customers: {summary['customers']}, Orders: {summary['orders']}.", "success")
    return redirect(url_for("dashboard"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    # Disable auto-reloader to avoid intermittent WinError 10038 on Windows.
    app.run(
        host=Config.FLASK_HOST,
        port=Config.FLASK_PORT,
        debug=Config.FLASK_DEBUG,
        use_reloader=False,
    )
