import re
from typing import Dict, Tuple

ORDER_STATUSES = ["Placed", "Packed", "Shipped", "Delivered", "Cancelled"]
EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def validate_email(email: str) -> bool:
    """Validate email with a lightweight regex suitable for form validation."""
    return bool(EMAIL_PATTERN.match(email or ""))


def parse_positive_float(value: str, field_name: str) -> Tuple[float, str]:
    """Return validated positive float and an error message (if invalid)."""
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return 0.0, f"{field_name} must be a valid number."

    if parsed <= 0:
        return 0.0, f"{field_name} must be greater than 0."

    return round(parsed, 2), ""


def parse_non_negative_int(value: str, field_name: str) -> Tuple[int, str]:
    """Return validated non-negative integer and an error message (if invalid)."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return 0, f"{field_name} must be an integer."

    if parsed < 0:
        return 0, f"{field_name} cannot be negative."

    return parsed, ""


def parse_positive_int(value: str, field_name: str) -> Tuple[int, str]:
    """Return validated positive integer and an error message (if invalid)."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return 0, f"{field_name} must be an integer."

    if parsed <= 0:
        return 0, f"{field_name} must be greater than 0."

    return parsed, ""


def normalize_phone(phone: str) -> str:
    """Keep only digits for consistent phone storage and searching."""
    return "".join(ch for ch in (phone or "") if ch.isdigit())


def generate_next_id(collection, id_field: str, prefix: str, start_number: int) -> str:
    """
    Generate sequential custom IDs like P101, C101, O1001.
    This implementation is simple and readable for college projects.
    """
    max_number = start_number - 1
    regex = f"^{prefix}\\d+$"

    for doc in collection.find({id_field: {"$regex": regex}}, {id_field: 1, "_id": 0}):
        raw_value = str(doc.get(id_field, ""))
        numeric_part = raw_value[len(prefix):]
        if numeric_part.isdigit():
            max_number = max(max_number, int(numeric_part))

    return f"{prefix}{max_number + 1}"


def build_status_badge(status: str) -> str:
    """Map order status to bootstrap badge class."""
    status_map: Dict[str, str] = {
        "Placed": "secondary",
        "Packed": "info",
        "Shipped": "primary",
        "Delivered": "success",
        "Cancelled": "danger",
    }
    return status_map.get(status, "dark")
