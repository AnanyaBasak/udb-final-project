(function () {
    const root = document.documentElement;
    const savedTheme = localStorage.getItem("ecom-theme") || "light";
    root.setAttribute("data-theme", savedTheme);

    const themeBtn = document.getElementById("themeToggle");
    if (themeBtn) {
        themeBtn.addEventListener("click", function () {
            const active = root.getAttribute("data-theme") === "dark" ? "dark" : "light";
            const next = active === "dark" ? "light" : "dark";
            root.setAttribute("data-theme", next);
            localStorage.setItem("ecom-theme", next);
        });
    }

    // Show a loading spinner on form submit.
    const spinnerModalEl = document.getElementById("loadingModal");
    const forms = document.querySelectorAll("form.show-spinner");
    if (spinnerModalEl && forms.length) {
        const loadingModal = new bootstrap.Modal(spinnerModalEl);
        forms.forEach((form) => {
            form.addEventListener("submit", function () {
                loadingModal.show();
            });
        });
    }

    const orderForm = document.getElementById("order-form");
    if (!orderForm) {
        return;
    }

    const body = document.getElementById("order-items-body");
    const addBtn = document.getElementById("add-item-row");
    const grandTotalEl = document.getElementById("grand-total");
    const productsScript = document.getElementById("products-json");

    if (!body || !addBtn || !grandTotalEl || !productsScript) {
        return;
    }

    const products = JSON.parse(productsScript.textContent || "[]");
    const productMap = {};
    products.forEach((p) => {
        productMap[p.product_id] = p;
    });

    function makeProductOptions(selectedId) {
        let html = '<option value="">Select Product</option>';
        products.forEach((p) => {
            const selected = p.product_id === selectedId ? "selected" : "";
            html += `<option value="${p.product_id}" ${selected}>${p.product_id} - ${p.name}</option>`;
        });
        return html;
    }

    function addRow(selectedId = "", qty = 1) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>
                <select class="form-select form-select-sm item-product" name="item_product_id" required>
                    ${makeProductOptions(selectedId)}
                </select>
            </td>
            <td class="item-stock text-muted">-</td>
            <td class="item-price text-muted">Rs. 0.00</td>
            <td>
                <input class="form-control form-control-sm item-qty" type="number" name="item_quantity" min="1" value="${qty}" required>
            </td>
            <td class="item-subtotal fw-semibold">Rs. 0.00</td>
            <td>
                <button type="button" class="btn btn-sm btn-outline-danger remove-row">Remove</button>
            </td>
        `;
        body.appendChild(tr);
        recalculateRow(tr);
        recalculateGrandTotal();
    }

    function recalculateRow(row) {
        const select = row.querySelector(".item-product");
        const qtyInput = row.querySelector(".item-qty");
        const stockEl = row.querySelector(".item-stock");
        const priceEl = row.querySelector(".item-price");
        const subtotalEl = row.querySelector(".item-subtotal");

        const product = productMap[select.value];
        const qty = parseInt(qtyInput.value || "0", 10);

        if (!product || qty <= 0) {
            stockEl.textContent = "-";
            priceEl.textContent = "Rs. 0.00";
            subtotalEl.textContent = "Rs. 0.00";
            row.dataset.subtotal = "0";
            return;
        }

        const subtotal = Number(product.price) * qty;
        stockEl.textContent = product.stock;
        priceEl.textContent = `Rs. ${Number(product.price).toFixed(2)}`;
        subtotalEl.textContent = `Rs. ${subtotal.toFixed(2)}`;
        row.dataset.subtotal = subtotal.toString();
    }

    function recalculateGrandTotal() {
        let grand = 0;
        body.querySelectorAll("tr").forEach((row) => {
            grand += Number(row.dataset.subtotal || "0");
        });
        grandTotalEl.textContent = `Rs. ${grand.toFixed(2)}`;
    }

    body.addEventListener("change", function (event) {
        if (event.target.classList.contains("item-product") || event.target.classList.contains("item-qty")) {
            const row = event.target.closest("tr");
            recalculateRow(row);
            recalculateGrandTotal();
        }
    });

    body.addEventListener("input", function (event) {
        if (event.target.classList.contains("item-qty")) {
            const row = event.target.closest("tr");
            recalculateRow(row);
            recalculateGrandTotal();
        }
    });

    body.addEventListener("click", function (event) {
        if (event.target.classList.contains("remove-row")) {
            const row = event.target.closest("tr");
            row.remove();
            if (!body.querySelector("tr")) {
                addRow();
            }
            recalculateGrandTotal();
        }
    });

    addBtn.addEventListener("click", function () {
        addRow();
    });

    addRow();
})();
